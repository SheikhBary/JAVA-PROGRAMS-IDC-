

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;


/**
 * Servlet implementation class demo1
 */
@WebServlet("/demo1")
public class demo1 extends HttpServlet {
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException
	
	{
		
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		
		pw.println("<html><body>");
		pw.println("Hello World <br>");
		pw.println("<body><html>");
		
		
		ServletContext context = getServletContext();
		//context.setAttribute("company", "HCL");
		String name =(String) context.getAttribute("company");
		
		
		pw.println("Welcome to " + name);
		pw.close();
	}
	
}
