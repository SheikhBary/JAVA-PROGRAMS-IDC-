

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class testServlet2
 */
@WebServlet("/serv2")
public class testServlet2 extends HttpServlet {
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException
	{
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		ServletContext context = getServletContext();
		
		String name = (String) context.getAttribute("Student");
		String name1 = (String) context.getAttribute("Student1");
		String name2 = (String) context.getAttribute("Student2");
		String name3 = (String) context.getAttribute("Student3");
		
		
		pw.println("  <tr style=\"background-color: #ABCDEF;color:#000000;\">\r\n"
				+ "    <th style = \"border:1px solid;\">Name</th>\r\n"
				+ "    <th style = \"border:1px solid;\">Contact</th>\r\n"
				+ "    <th style = \"border:1px solid;\">Age</th>\r\n"
				+ "  </tr><br>\r\n");
		
		
		pw.println("<td style = \\\"border:1px solid;\\\"></td>\\r\\n\""+name1+"\"");
		
		pw.println(name1 + 9666444+21 +"<br>");
		pw.println(name2 + 9666444+21 +"<br>");
		pw.println(name3 + 9666444+21 +"<br>");
		pw.close();
		
		
		
	}
	
}
