


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
/**
 * Servlet implementation class employee
 */
@WebServlet("/employee")
public class employee extends HttpServlet {
public void doGet(HttpServletRequest req, HttpServletResponse res) throws IOException
	
	{
		
		res.setContentType("text/html");
		PrintWriter pw = res.getWriter();
		
		pw.println("<html><body>");
		pw.println("Hello World from Employee <br> Name Of Employees");
		pw.println("<br> <ul><li>Sheikh</li> <br> <li>Abdul</li><br>  <li>Bary</li><br>  <li>Varun</li><br>  <li>Kamala</li></ul>");
		pw.println("<table style=\" border: 1px solid;\">\r\n"
				+ "  <tr style=\"background-color: #ABCDEF;color:#000000;\">\r\n"
				+ "    <th style = \"border:1px solid;\">Name</th>\r\n"
				+ "    <th style = \"border:1px solid;\">Contact</th>\r\n"
				+ "    <th style = \"border:1px solid;\">Age</th>\r\n"
				+ "  </tr>\r\n"
				+ "  <tr>\r\n"
				+ "    <td style = \"border:1px solid;\">Alfreds Futterkiste</td>\r\n"
				+ "    <td style = \"border:1px solid;\">96885411</td>\r\n"
				+ "    <td style = \"border:1px solid;\">33</td>\r\n"
				+ "  </tr>\r\n"
				+ "  <tr>\r\n"
				+ "    <td style = \"border:1px solid;\">Bruce</td>\r\n"
				+ "    <td style = \"border:1px solid;\">98886444</td>\r\n"
				+ "    <td style = \"border:1px solid;\">45</td>\r\n"
				+ "  </tr>\r\n"
				+ "  </tr>\r\n"
				+ "  <tr>\r\n"
				+ "    <td style = \"border:1px solid;\">Sheikh</td>\r\n"
				+ "    <td style = \"border:1px solid;\">96385274</td>\r\n"
				+ "    <td style = \"border:1px solid;\">25</td>\r\n"
				+ "  </tr>\r\n"
				+ "  </tr>\r\n"
				+ "  <tr>\r\n"
				+ "    <td style = \"border:1px solid;\">Abdul</td>\r\n"
				+ "    <td style = \"border:1px solid;\">85296374</td>\r\n"
				+ "    <td style = \"border:1px solid;\">23</td>\r\n"
				+ "  </tr>\r\n"
				+ "  </tr>\r\n"
				+ "  <tr>\r\n"
				+ "    <td style = \"border:1px solid;\">Bary</td>\r\n"
				+ "    <td style = \"border:1px solid;\">98765432</td>\r\n"
				+ "    <td style = \"border:1px solid;\">38</td>\r\n"
				+ "  </tr>\r\n"
				+ "</table>");
		
		
		pw.println("<body><html>");
	}
	
}
