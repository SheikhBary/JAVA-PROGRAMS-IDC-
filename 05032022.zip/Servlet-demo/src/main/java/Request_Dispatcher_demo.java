

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class Request_Dispatcher_demo extends HttpServlet {
	public void doPost (HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		String n =req.getParameter("userName");
		String p =req.getParameter("pass");
		
		
		
		if (p.equals("password") && n.equals("Sheikh"))
			
		{
			RequestDispatcher rd = req.getRequestDispatcher ("welcome");
			rd.forward(req, res);
		}else
		{
			out.print("Sorry username and password is incorrect");
			RequestDispatcher rd = req.getRequestDispatcher ("/NewFile.html");
			rd.include(req, res);
		}
		
	}
}
