package Methods;



class stu {
	
	int reg_no;
	String university, address, dept;
	
	stu(){
		
		System.out.println("Default constructor");
		System.out.println("________________________");
		
	}
	
	
	stu(int reg_no, String university){
		
		this.reg_no=reg_no;
		this.university=university;
		
	}
	
	stu(int reg_no, String university, String address, String dept){
		
		this.reg_no=reg_no;
		this.university=university;
		this.address=address;
		this.dept=dept;
	}
	
	
	void display() {
		
		System.out.println("Name of the University" +university);
		System.out.println("Registered code" +reg_no);
		System.out.println("Registered Address:" +address);
		System.out.println("Registered Department:" +dept);
	}
	
	
	
}
public class constructor_overloading {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		stu s1 = new stu();
		stu s2 = new stu (1011, "Oxford");
		stu s3 = new stu (1011, " Oxford", "England", "Law");
		
		s1.display();
		s2.display();
		s3.display();

	}

}
