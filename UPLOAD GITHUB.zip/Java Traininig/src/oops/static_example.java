package oops;
import java.util.Scanner;
public class static_example {

	
	static int a;
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner (System.in);
		System.out.println("Enter A value");
		a=s.nextInt();
		
		System.out.println(a);

	}

}
