package oops;



abstract class shape {
	shape(){
	System.out.println("Abstract Class");
	}
	
	abstract String draw();
}


class circle extends shape {
	String draw() 
	{
	return "circle";
	}
	
}


class square extends shape{
	String draw() 
	{
	return "Square";
	}

}


class rectangle extends shape {
	String draw() 
	{
	return "rectangle";
	}
}


public class abstract_shape {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		circle c = new circle ();
		square s = new square ();
		rectangle r = new rectangle ();
		
		
		System.out.println(c.draw()+ " is drawing");
		System.out.println(s.draw()+ " is drawing");
		System.out.println(r.draw()+ " is drawing");

	}

}
