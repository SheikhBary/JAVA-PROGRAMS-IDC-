package oops;


class parent2{
	
	void show() {
		
		
	}
	int calculate2(int a , int b, int c) {
		
		return a*b*c;
	}
	
}

class child2 extends parent2{
	
void show() {
		
		
	}
int calculate2(int a , int b, int c) {
		
	return a*b/c;
	}
	
}

class child3 extends child2{
	
void show() {
		
		
	}
int calculate2(int a , int b) {
		
	return a-b;
	}
	
}

public class method_overiding_challenge {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		parent2 p2 = new parent2();
		child2 c2 = new child2();
		child3 c3 = new child3();
		
		p2.show();
		c2.show();
		c3.show();
		
		System.out.println(p2.calculate2(20, 30, 20));
		System.out.println(c2.calculate2(20, 30,10));
		System.out.println(c3.calculate2(20, 30));
	
		

	}

}
