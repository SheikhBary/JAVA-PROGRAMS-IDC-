package oops;
import java.util.Scanner;

class Stu{
	
	
	
}


class mark_data{
	
	
	
}
class mark_list extends mark_data{
	
	
	
}

public class Multilevel_Inheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
