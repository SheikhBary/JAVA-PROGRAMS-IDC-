package oops;
import java.util.Scanner;

class leap_year{
	
	static int year=2020;
	Scanner s = new Scanner (System.in);
	
	static void year()
	
	{
		
		
		
		if (year%4==0) {
			
			
			System.out.println(year+" year is a leap year");
		}
		
		else {
			
			System.out.println(year+" year is not a leap year");
		}
	}
}
public class static_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		leap_year.year();
		leap_year.year=2025;
		leap_year.year();
		
		

	}

}
