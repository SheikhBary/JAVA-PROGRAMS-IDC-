package oops;

public class default_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		child2 c = new child2();
		c.show();
		System.out.println(c.calculate2(10,49));

	}

}
