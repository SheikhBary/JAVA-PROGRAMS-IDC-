package oops;


class Bank{
	
	String ifsc,address,name;
	int zipcode;
	
	Bank(String ifsc, String address, int zipcode, String name){
		
		this.ifsc=ifsc;
		this.address = address;
		this.zipcode =zipcode;
		this.name=name;
	}
	
	Bank(){
		
		System.out.println("Default constructor");
	}
	
	
	void display() {
		
		System.out.println("Bank Name:" + name);
		System.out.println("Address:" + address);
		System.out.println("IFSC:" + ifsc);
		System.out.println("Zip Code:" + zipcode);
		
	}
}
public class constructor_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Bank b = new Bank();
		Bank b1 = new Bank ("ICIC00231", "city1, state",624771, "ICICIC" );
		b.display();
		b1.display();

	}

}
