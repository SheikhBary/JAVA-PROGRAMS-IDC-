
public class WelcomeClassExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello World");
		
		
		int course_id;
		
		String course_name;
		
		
		course_id = 1010;
		course_name="Java Training 101";
		
		System.out.println("The course id is" + course_id +" and the course name is" + course_name);
		
		
	}

}
