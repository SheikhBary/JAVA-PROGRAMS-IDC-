package Exception_Handling;
import java.io.*;

class Parent {
	
	void msg()throws IOException {
		
		System.out.println("parent method");
	}
}


public class override_ex extends Parent{
	void msg (){
		System.out.println("child method");
	}
	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
			Parent p = new override_ex();
			p.msg();
	
	}

}
