package Exception_Handling;

public class task_finallyException {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			
			int a=5,b=0;
			b=a/b;
		
		}catch(ArithmeticException e) {
			
			System.out.println(e);
		}
		
		finally{
		
		System.out.println("The rest of code in final block");
		}
	}

}
