package Exception_Handling;

public class number_format_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int decimalExample = Integer.parseInt("20");
		int signedPositive = Integer.parseInt("+20");
		int signedNegative = Integer.parseInt("-20");
		
		System.out.println("Value=" +decimalExample);
		System.out.println("Value=" +signedPositive);
		System.out.println("Value=" +signedNegative);
		
		try {
		int a = Integer.parseInt("null");
		}catch(Exception e)
		
		{
			System.out.println(e);
		}
	}

}
