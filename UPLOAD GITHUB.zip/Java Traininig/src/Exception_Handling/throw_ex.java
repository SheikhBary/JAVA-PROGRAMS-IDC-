package Exception_Handling;

public class throw_ex {
	
	static void checkAge(int age)
	
	{
		if (age<18) {
		throw new ArithmeticException ("Access is denied, you need to be 18 years old!");
		
		}
		
		else 
		{
			System.out.println("Success");
			
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		checkAge(17);

	}

}
