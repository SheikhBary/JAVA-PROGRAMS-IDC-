package Looping_stmts;
import java.util.*;
public class challenge_array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner s = new Scanner(System.in);
		
		int r,c;
		
		System.out.println("Enter the number of rows:");
		r=s.nextInt();
		
		
		System.out.println("Enter the number if columns:");
		c=s.nextInt();
		
		
		
		
		int table1[][]=new int [r][c];
		int add_table [][]=new int[r][c]; 
		
		int table2 [][]=new int[r][c];
		
		//Table1
		
		System.out.println("Enter the number of table1:");
		
		for (int i=0; i<r;i++) {
			
			for (int j=0;j<c;j++) {
				
				table1[i][j]=s.nextInt();	
						}
			
		}
		
		//Table2
		
		System.out.println("Enter the number of table2:");
		
		for (int i=0; i<r;i++) {
			
			for (int j=0;j<c;j++) {
				
				table2[i][j]=s.nextInt();			
						}
		}
		
		
	    //TableAdd
			
			System.out.println("Addition of the two tables:");
			
			for (int i=0; i<r;i++) {
				
				for (int j=0;j<c;j++) {
					
					add_table[i][j]=table1[i][j]+table2[i][j];
			
				}
			}
			
			for (int i=0;i<r;i++) {
				
				for (int j=0;j<c;j++) {
					
					System.out.print(add_table[i][j] + "");
					
				}
				
				System.out.println("");
				
				
			}
			
		
			
			
		
	}

	}
