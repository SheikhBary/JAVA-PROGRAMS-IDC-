package Looping_stmts;
import java.util.Scanner;
public class array_java_ex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner (System.in);
		int no_of_emps;
		
		
		System.out.println("Enter the number of employees");
		no_of_emps=s.nextInt();
		
		int emp_id[] =new int [no_of_emps];
		String emp_name[]= new String [no_of_emps];
		String dept [] = new String [no_of_emps];
		
		System.out.println("Enter employee details");
		
		for (int i=0; i<no_of_emps;i++) {
			
			System.out.println("Employee Id");
			emp_id[i]=s.nextInt();
			
			System.out.println("Employee Name");
			emp_name[i]=s.next();
			
		}
		
		System.out.println("Employee Id");
		for ( int i:emp_id)
		
		{
			System.out.println("Employee Id"+i);
			
		}
		
		System.out.println("Employee Names");
		
		for(String i :emp_name)
		{
			
			System.out.println("Employee Names" + i);
		}
	}

}
