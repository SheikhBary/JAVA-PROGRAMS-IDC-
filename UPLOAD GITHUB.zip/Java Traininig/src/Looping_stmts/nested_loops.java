package Looping_stmts;
import java.util.*;
public class nested_loops {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for (int i=0; i<5; i++) {
			
			
			for(int j=0; j<5; j++) {
				
				
				System.out.print(i + " ");
			}
			
			System.out.println();
		}
		
		

	}

}
