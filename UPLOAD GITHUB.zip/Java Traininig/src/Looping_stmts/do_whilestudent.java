package Looping_stmts;
import java.util.Scanner;
public class do_whilestudent {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s =new Scanner (System.in);
String stdName, dob, regNo,department,grade,result = null;
		
		int mark1,mark2,mark3,ttlmark, avgMark,i;
		
		System.out.println("Enter Number of Students");
		int nos =s.nextInt();
		i=0;
		do {

			System.out.println("Enter Student Name");
			stdName=s.next();
			
			System.out.println("Enter Student DOB");
			dob=s.next();
			
			System.out.println("Enter Student Registration Number");
			regNo=s.next();
			
			System.out.println("Enter Student's Department");
			department=s.next();
			
			System.out.println("Enter First Mark");
			mark1=s.nextInt();
			
			System.out.println("Enter Second Mark");
			mark2=s.nextInt();
			
			System.out.println("Enter Third Mark");
			mark3=s.nextInt();
			
			ttlmark = mark1 +mark2+mark3;
			avgMark= ttlmark/3;
			if (avgMark<25) {
				
				grade = "F";
				result="fail";
				
				
			}
			else if (avgMark>24 && avgMark<50){
				
				grade = "D";
				result="fail";
			}
			
			else if (avgMark>49 && avgMark<57){
				
				grade = "D";
				result="fail";
			}
			
			else if (avgMark>56 && avgMark<62){
				
				grade = "C";
				result="pass";
			}
			
			else if (avgMark>62 && avgMark<75){
				
				grade = "B";
				result="pass";
			}
			
			else if (avgMark>74 ){
				
				grade = "A";
				result="pass";
			}
			
			else {
				grade = "NIL";
				
			}
			
			
			
			
			System.out.println("===================================================");
			System.out.println("Student Marklist");
			System.out.println("===================================================");
			
		
	System.out.println("Student Name:" + stdName + "                          " + "D.o.B:"+ dob);		
			
	System.out.println("RegNo:" +regNo);		
			

	System.out.println("-----------------------------------------------------------------");

	System.out.println("First Mark:" + mark1+"                          " + "Department:"+ department);
	System.out.println("Second Mark:" + mark2);
	System.out.println("Third Mark:" + mark3);
	System.out.println("-----------------------------------------------------------------");
	System.out.println("Total Mark:" + ttlmark +"                          " + "Average Mark:"+ avgMark);		
	System.out.println("Result:" + result +"                               " + "Grade:" +grade);			
		i++;
			
			
		}while(i<nos);
	}

}
