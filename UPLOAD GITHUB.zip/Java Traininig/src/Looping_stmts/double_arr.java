package Looping_stmts;
import java.util.*;
public class double_arr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s = new Scanner(System.in);
		
		System.out.println("Enter the no of columns");
		int c = s.nextInt();
		
		System.out.println("Enter the no of row");
		int r = s.nextInt();
		
		
		int table [][] =new int [r][c];

		
		System.out.println("Enter the data for the table");
		
		for (int i=0;i<r;i++) {
			
			for (int j=0;j<c;j++) {
				
				table[i][j]	=s.nextInt();	
						}
		}
		
		for (int i=0;i<r;i++) {
			
			
			for (int j=0;j<c;j++) {
				
				System.out.print(table[i][j]);
			}
			
			System.out.println();
		}
	}

}
