package Multi_Thread;
import java.util.Scanner;


public class runnable_Ex implements Runnable {
	
	public void run() {
		Scanner s = new Scanner (System.in);
		System.out.println("Enter n Value");
		int n =s.nextInt();
		
		for (int i=0;i<n;i++)
			
		{
			System.out.println(i*i);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		runnable_Ex r = new runnable_Ex();
		Thread t =new Thread(r);
		t.start();
		
	}

}
